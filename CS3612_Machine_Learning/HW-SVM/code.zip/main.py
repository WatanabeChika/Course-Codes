from dataset import get_data,get_HOG,standardize

if __name__ == '__main__':
######################## Get train/test dataset ########################
    X_train,X_test,Y_train,Y_test = get_data('dataset')
########################## Get HoG featues #############################
    H_train,H_test = get_HOG(X_train), get_HOG(X_test)
######################## standardize the HoG features ####################
    H_train,H_test = standardize(H_train), standardize(H_test)
########################################################################
######################## Implement you code here #######################
########################################################################
    from sklearn.svm import SVC
    import numpy as np
    from matplotlib import pyplot as plt

    # Test hyperparameters
    def test_hyperparameters():
        print("------Different value of C------")
        C_value = [0.001, 0.01, 0.1, 1, 10, 100, 1000]
        for c in C_value:
            # Linear SVM
            LinearSVM = SVC(kernel='linear', C=c)
            LinearSVM.fit(H_train, Y_train)
            test_score = LinearSVM.score(H_test, Y_test)
            print(f"Linear SVM with C={c} has test score of {test_score}")
            # RBF kernel SVM
            RBF_SVM = SVC(kernel='rbf', C=c)
            RBF_SVM.fit(H_train, Y_train)
            test_score = RBF_SVM.score(H_test, Y_test)
            print(f"RBF SVM with C={c} has test score of {test_score}")
            # Polynomial kernel SVM
            Poly_SVM = SVC(kernel='poly', C=c, degree=3)
            Poly_SVM.fit(H_train, Y_train)
            test_score = Poly_SVM.score(H_test, Y_test)
            print(f"3-degree Polynomial SVM with C={c} has test score of {test_score}")

        print("------Different value of degree------")
        for d in range(1, 6):
            Poly_SVM = SVC(kernel='poly', C=10, degree=d)
            Poly_SVM.fit(H_train, Y_train)
            test_score = Poly_SVM.score(H_test, Y_test)
            print(f"{d}-degree Polynomial SVM with C=10 has test score of {test_score}") 

    # Linear SVM
    def LinearSVM():
        # Choose C=1
        LinearSVM = SVC(kernel='linear', C=1)
        LinearSVM.fit(H_train, Y_train)

        # get support vectors
        support_vector_indices = LinearSVM.support_
        print(f"Number of support vectors: {len(support_vector_indices)}")
        # get other data
        dual_coef = LinearSVM.dual_coef_
        distance = LinearSVM.decision_function(H_train)
        sorted_dis = sorted(distance)

        # most confident 10 predictions (5 positive, 5 negative)
        confident_images = {}
        for dis_val in sorted_dis[:5] + sorted_dis[-5:]:
            X_index = np.where(distance == dis_val)
            confident_images[int(X_index[0])] = dis_val
        # draw them in one figure
        for i, (index, dis) in enumerate(confident_images.items()):
            plt.subplot(2, 5, i+1)
            plt.imshow(X_train[index].reshape(42, 42, 1))
            plt.title("d: {:+.3f}".format(dis))
            plt.axis('off')
        plt.show()

        # support vectors (5 negtive)
        support_vector_images = {i: support_vector_indices[i] for i in range(5)}
        # draw them in one figure
        for i, index in support_vector_images.items():
            plt.subplot(1, 5, i+1)
            plt.imshow(X_train[index].reshape(42, 42, 1))
            plt.title("α: {:.1e}".format(abs(dual_coef[0][i])))
            plt.axis('off')
        plt.show()
        
        # test score
        test_score = LinearSVM.score(H_test, Y_test)
        print(f"Linear SVM has test score of {test_score}")

    # RBF kernel SVM
    def RBF_SVM():
        C_value = [0.001, 0.01, 0.1, 1, 10, 100, 1000]  # >=1 is the best
        # try different C values
        for c in C_value:
            RBF_SVM = SVC(kernel='rbf', C=c)
            RBF_SVM.fit(H_train, Y_train)
            # get support vectors
            support_vector_indices = RBF_SVM.support_
            print(f"Number of support vectors with C={c}: {len(support_vector_indices)}")
            # test score
            test_score = RBF_SVM.score(H_test, Y_test)
            print(f"RBF SVM with C={c} has test score of {test_score}")

    # Polynomial kernel SVM
    def Polynomial_SVM():
        # Choose C=10, degree=3
        Poly_SVM = SVC(kernel='poly', C=10, degree=3)
        Poly_SVM.fit(H_train, Y_train)
        # test score
        test_score = Poly_SVM.score(H_test, Y_test)
        print(f"3-degree Polynomial SVM has test score of {test_score}")
    
    # Choose SVM hyperparameters
    # test_hyperparameters()

    # Run the functions
    print("-------------------- Linear SVM --------------------")
    LinearSVM()
    print("---------------------- RBF SVM ----------------------")
    RBF_SVM()
    print("------------------ Polynomial SVM ------------------")
    Polynomial_SVM()

    