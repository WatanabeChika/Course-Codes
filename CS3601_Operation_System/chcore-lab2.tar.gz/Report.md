### 练习题1
![split](images/image.png)
如图所示，用切换order的方法进行chunk的分割，并得到同order的伙伴块。

![merge](images/image-1.png)
如图所示，得到伙伴块之后，直接选取地址更低的chunk增加order即可进行合并，注意伙伴块的属性检查。

![getpage](images/image-2.png)
按order从当前到最大，在freelist上获取空闲块即可，注意维护各种变量。

![freepage](images/image-3.png)
直接释放块，注意维护各种变量。

### 练习题2
![choose](images/image-4.png)
![alc](images/image-5.png)
![free](images/image-6.png)
如图所示，完成slab的分配主要任务是理解各种类的属性和需要维护的各种变量，注意链表为空的情况即可。

### 练习题3
![kmalloc](images/image-7.png)
如图所示，这里比较简单。

### 练习题4
![query](images/image-8.png)
如图所示，需要弄清楚一层层访问页表该如何实现，注意一些极端情况。

![map](images/image-9.png)
如图所示，这里应为本次作业最难的一个函数。需要弄清楚```len```的意义，在地址上通过偏移来映射多个页表。此外，在调用```set_pte_flags```之前需要手动给pte设置几个属性。还需要注意访问失败的情况。

![unmap](images/image-10.png)
和map的流程相似，省去了设置属性的过程，但是需要考虑大页的unmap，在访问页表时就应检查是否是大页。

![mprotect](images/image-11.png)
和unmap极为相似，改动设置属性的相关语句即可。

### 思考题5
相关字段：AP，即Access Permission，Read Only时是2，Read Write权限应该将其设置成3即可。

在发生页错误时，操作系统通过CPU寄存器的内容进入对应的异常处理函数，再判断是否是CoW异常，如果否，则抛出异常；如果是，则进行对应的CoW处理。

### 思考题6
粗粒度映射会导致内存的空间利用率不高，因为有些程序实际上需要的内存还不及一个页表的大小。

### 练习题8
![pf](images/image-12.png)
如图所示，调用对应函数即可。

### 练习题9
![vms](images/image-13.png)
如图所示，调用函数进行树搜索即可。

### 练习题10
![pgh](images/image-14.png)
三段代码的补充都需要理解层次结构，知道对应部分实现的功能，然后补充即可。
