### 思考题1
程序将CPU的ID值```mpidr_el1```读入x8寄存器里，与0xFF进行与运算来选出主CPU，主CPU会跳转到```primary```执行boot，其他CPU继续执行至```wait_until_smp_enabled```并被阻塞，直至```secondary_boot_flag```被主CPU设置。

### 思考题2
1. 虚拟地址，因为在设置```secondary_boot_flag```的函数前先启动了MMU：```el1_mmu_activate()```，则之后使用的地址均为虚拟地址。
2. 通过main函数的参数```boot_flag```传入。
3. 传入main函数的```boot_flag```值是物理地址，在```enable_smp_cores```函数里将其转换成了虚拟地址：```secondary_boot_flag = (long *)phys_to_virt(boot_flag);```，之后通过这个地址一个个激活CPU。

### 练习题1
分别初始化list、lock和参数queue_len即可。

### 练习题2/练习题3
补充出队入队操作，即添加（list_append）/删除（list_del）thread属性里的链表项，并维护queue_len属性即可。

### 练习题4
主动调用线程调度：运行```sched```函数。

将当前线程加入调度队列：运行```rr_sched_enqueue```函数，将当前线程入队。

### 练习题5
根据注释，书写汇编代码，为对应的寄存器赋值。
要注意的是，```CNTP_CTL_EL0```寄存器的赋值要注意二进制位的开启/关闭含义。

### 练习题6
按照注释进行填写即可。
要注意的是，在```handle_timer_irq```函数里，要判断当前进程是否存在，再进行时间片递减和调度操作。

### 练习题7
只需要填写赋值对象的值即可，将```connection.h```里各个类的属性对应上进行填写即可。