### 练习题1
根据提示调用函数即可，注意alloc的size参数和init的size参数需不同，前者是定义出的cap_group或vmspace的size，后者是BASE_OBJ_NUM。

### 练习题2
仿照第一个flag的示例进行offset、vaddr、filesz和memsz的加载，注意不同参数有不同的物理偏移量。

分配地址给segment_pmo，然后把elf文件加载进该地址，再设置flag。注意这里的参数变化。

### 练习题3
根据提示，将thread里的几个特殊寄存器设置成对应的值即可。

### 思考题4
完成必要的初始化：运行完main函数的create_root_thread()。
sched() -> 
调用当前调度算法cur_sched_ops->sched() ->
按照算法选择到当前thread ->
调用switch_context()进行上下文切换 ->
调用eret切换到第一个用户态程序

### 练习题5
用下文里的异常类型作为参数，按顺序建立异常入口表即可。

在下文对应的异常类型里，填充需要跳转的函数名称。

### 练习题6
根据提示，先留出足够的栈空间，然后保存寄存器值到栈内，将特殊寄存器移到普通寄存器后也要存入栈内。之后再进行内核栈切换，当前cpu的stack在smp.h里。

### 思考题7
printf() -> vfprintf() -> 描述符stdout -> 描述符stdout_ops -> .write=chcore_stdout_write

### 练习题8
因有2个参数，直接调用syscall2即可，将函数名和参数传进去。

### 练习题9
编写文件(test.c)后用下列指令直接编译：

```sudo aarch64-linux-gnu-gcc "$@" -specs "/home/os/OS-Course-Lab/build/chcore-libc/lib/musl-gcc.specs" test.c -o hello_chcore.bin```

然后将bin文件放入ramdisk即可