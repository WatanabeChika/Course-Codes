#include <stdio.h>

int main(int argc, char const *argv[]) {
    printf("Hello ChCore!");
    printf("瑠璃思う、ゆえに瑠璃あり。");
    return 0;
}